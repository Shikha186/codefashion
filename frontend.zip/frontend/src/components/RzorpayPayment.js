// RazorpayPayment.js
import React from 'react';
import Razorpay from 'razorpay';

const RazorpayPayment = () => {
  const handlePayment = async () => {
 
    const response = await fetch('http://localhost:5000/create-order', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ amount: 50000 }), 
    });
    if (!response.ok) {
      throw new Error(`HTTP error! Status: ${response.status}`);
    }
    const orderData = await response.json();
    console.log('Order data:', orderData);
   
    
    const options = {
      key: 'rzp_test_eYNQfs9koLGuW9', 
      amount: orderData.amount, // Amount in paise 
      currency: orderData.currency,
      name: 'Prachi Gupta',
      description: 'Test Transaction',
      image: 'https://example.com/logo.png', 
      order_id: orderData.id,
      handler: (response) => {
        // Handle successful payment here
        alert(`Payment successful! Payment ID: ${response.razorpay_payment_id}`);
      },
      prefill: {
        name: 'Customer Name',
        email: 'customer@example.com',
        contact: '9999999999',
      },
      theme: {
        color: '#F37254',
      },
    };

   
    const razorpay = new window.Razorpay(options);
    razorpay.open();
  };

  return (
    <div>
      <button onClick={handlePayment} style={{ padding: '10px', fontSize: '16px' }}>
        Pay Now
      </button>
    </div>
  );
};

export default RazorpayPayment;
